settings = {
 
}
# не реализовано 