from Heart.Record.ByteStreamHelper import ByteStreamHelper
from Heart.Packets.PiranhaMessage import PiranhaMessage


class OwnHomeDataMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
        self.writeVInt(1709465260)
        self.writeVInt(1392545451)
        self.writeVInt(2024063)
        self.writeVInt(73939)

        self.writeVInt(player.Trophies) # Trophies
        self.writeVInt(player.Trophies) # Trophies
        self.writeVInt(player.HighestTrophies) # high trophies

        self.writeVInt(999) # trophy road tier
        self.writeVInt(99999) # experience

        self.writeDataReference(28, player.Thumbnail) # thumbnail
        self.writeDataReference(43, player.Namecolor) # name color

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        
        self.writeVInt(843)
        for i in range(843):
            self.writeDataReference(29, i)
        
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(1)
        self.writeVInt(0)

        self.writeVInt(124)
        self.writeVInt(1287139)
        self.writeVInt(743539)
        self.writeVInt(336739)
        self.writeVInt(200)
        self.writeVInt(200)
        self.writeVInt(5)
        self.writeVInt(93)
        self.writeVInt(206)
        self.writeVInt(456)
        self.writeVInt(1001)
        self.writeVInt(2264)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(2)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(200)
        self.writeVInt(-64)
        self.writeVInt(3)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(2)
        self.writeVInt(0)
        self.writeVInt(0)

        self.writeByte(1) # count brawlers selected
        self.writeDataReference(16, player.SelectedBrawlers[0]) # selected brawler
        
        self.writeString(player.Region) # location
        self.writeString(player.ContentCreator) # v54 support

        self.writeVInt(0) # IntValueEntry

        self.writeVInt(0)
        
        self.writeVInt(1) # BrawlPass Seasons
        for i in range(1):
            self.writeVInt(23) # Brawl Pass Season
            self.writeVInt(0) # Tokens
            self.writeVInt(2) # Brawl Pass Unlocked
            self.writeVInt(0)
        self.writeHexa('020000000000000000000000000000000001000000000000000000000000000000000200000000000000000000000000000000000100A38D29000001000000000000000000')
        self.writeHexa('7F')
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeHexa('BF89F7')
        self.writeVInt(0)
        self.writeHexa('23')
        for i in range(9):
            self.writeVInt(i)
        self.writeHexa('0A0B0C0D0E0F101112131415161718191A1B1C1D1E1F202122230EE18EE88808010000938309050F800B7F')
        
        self.writeInt(0)
        self.writeInt(0)
        self.writeInt(0)
        self.writeInt(0)

        self.writeVInt(0)

        self.writeString('')
        self.writeVInt(0)
        self.writeString('')
        self.writeVInt(0)
        self.writeHexa('C1D592880802000093E003050FBD0A7F')

        self.writeInt(0)
        self.writeInt(0)
        self.writeInt(0)
        self.writeInt(0)

        self.writeVInt(0)

        self.writeHexa('7F')
        self.writeVInt(0)
        self.writeString('')
        self.writeVInt(0)
        self.writeHexa('C1ADCF86')
        self.writeVInt(8)
        self.writeVInt(3)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeHexa('B3B106050F077F00000000000000000000000000000000007F007F7F7F7F00C1B1AA8408040000B38E')
        self.writeVInt(0)
        self.writeVInt(5)
        self.writeHexa('0F8F')
        self.writeVInt(7)
        self.writeHexa('7F')

        self.writeInt(0)
        self.writeInt(0)
        self.writeInt(0)
        self.writeInt(0)

        self.writeVInt(0)

        self.writeHexa('7F')
        self.writeVInt(0)
        self.writeHexa('7F7F7F7F')
        self.writeVInt(0)
        self.writeHexa('C181B1870805000093E003000FBE0A7F00000000000000000000000000000000007F007F7F7F7F00C1858C8508060000B38E01050FB6077F00000000000000000000000000000000007F007F7F7F7F00DE86C8FF070C00009B9F0905001100000000000000000000000000000000007F007F7F7F7F00FECCF2FE070D0000ABD709050009000000000000000000000002078C90AF0F00000004D7A1D7A10936010000009C5B0E0000789C33E0323300A1700A00AD34FBC200599AF5206040341B012145369B0C88661F3AD98C16B1A85C6CB18EA2D9044FDC6073075535836216876670A4D3C866B074000ECDFE9826636AC66F336ECDF8F220A1A822198C6A1E2C9A2BF520902CCDD034459EE6519BE969334130AA79E469A6A8D087D428A138AA9B285AD65543B472A748F368FD3CAA799069F65530513034E102002D319F6207B2E8F91200000011D791D79F20D795D790D79CD799D7A9D799057F00000000007F007F7F7F7F00A48F8E0B14000083CB0800')
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeHexa('7F')
        self.writeVInt(0)
        self.writeInt(-1)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(3)
        self.writeInt(0)
        self.writeInt(0)
        self.writeVInt(2)
        self.writeInt(0)
        self.writeVInt(2)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeHexa('7F7F7F7F00A58F8E0B15000083CB08000FB6')
        self.writeVInt(0)
        self.writeHexa('7F')
        self.writeVInt(3)
        self.writeInt(-1)
        self.writeHexa('0000030000000000000000007F007F7F7F7F00A68F8E0B16000083CB08000FB3017F03')
        self.writeInt(-1)
        self.writeHexa('0000030000000000000000007F007F7F7F7F00A78F8E0B17000083CB08000FAC047F03')
        self.writeInt(-1)
        self.writeHexa('0000030000000000000000007F007F7F7F7F00A88F8E0B18000083CB08000FA4087F03FFFFFFFF0000030000000000000000007F007F7F7F7F00E1BEE18508210000938309050FAF097F00000000000000000000000000000000007F007F7F7F7F000BC1F4DB8808010093830993C913050FB4077F00000000000000000000000000000000007F007F7F7F7F00E1BA868808020093E00393A60E050FA4037F00000000000000000000000000000000007F007F7F7F7F00E192C386080300B3B106B3F710050FBA017F00000000000000000000000000000000007F007F7F7F7F00E1969E84080400B38E01B3D40B050F89027F00000000000000000000000000000000007F007F7F7F7F00E1E6A48708050093E00393A60E000FA5037F00000000000000000000000000000000007F007F7F7F7F00E1EAFF84080600B38E01B3D40B050FAF057F00000000000000000000000000000000007F007F7F7F7F00FEEBBBFF070C009B9F099BE51305000600000000000000000000000000000000007F007F7F7F7F00DEB2E6FE070D00ABD709AB9D1405001100000000000000000000000000000000007F007F7F7F7F00130E00A3BB09A3EFC502')
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeHexa('7F')
        self.writeVInt(0)
        self.writeInt(0)
        self.writeInt(0)
        self.writeInt(0)
        self.writeVInt(1)
        self.writeHexa('13')
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeHexa('185449445F425241574C5F504153535F534541534F4E5F3234') # TID_BRAWL_PASS_SEASON_24
        self.writeHexa('90B6ACDE0C90EAE8E00C00000000000100000006')
        self.writeHexa('52414E4B4544')
        self.writeVInt(0)
        self.writeVInt(2)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeHexa('11')
        self.writeHexa('52616E646F6D204D6F64652026204D6F64')
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeHexa('7F00120F050F160F91010F84020FB6010F800B0FBA010FB3010F97050F130F88010F89020FB2040FAC040FA6040FB0050FA4080FBF0A7F04161F20177F00C1A4D58508210093830993C913050F97097F00000000000000000000000000000000007F007F7F7F7F009CB50123A3A553A3BD7DA38F9D0100007F00FFFFFFFF000000000000000000000001000000084D4547412050494700020000001252616E646F6D204D61702026204D6F64732100007F000C0F870B0F880B0F860B0F840B0F850B0F830B0F8D0B0F8E0B0F8C0B0F8B0B0F890B0F8A0B7F0417141D157F010F01030302010A14238B018C02A204A007A00CA213931DB02B041E9001AA02A80504AC04B00DB81F8849181DAA0BFF964946FFFFFFFFFFFFFFFF011DB00BFF98EC46FFFFFFFFFFFFFFFF011DB60BFFB214E6FFFFFFFF00000000011DB90BFFAE0446FFFFFFFFFFFFFFFF011DAF0BFFBC84C6FFFFFFFFFFFFFFFF011DB80BFFAE3FCEFFFFFFFF00000000011DA80BFFE411C6FFFFFFFFFFFFFFFF011DA70BFFE6B4C6FFFFFFFFFFFFFFFF011DB10BFFE80646FFFFFFFFFFFFFFFF011DB50BFFD83446FFFFFFFF00000000011DB70BFFD6E2C6FFFFFFFFFFFFFFFF011D840CFFF929C6FFFFFFFFFFFFFFFF001D960CFFFD1E46FFFFFFFFFFFFFFFF001D8D0CFFFE6FC6FFFFFFFFFFFFFFFF001D8C0CFFFFC146FFFFFFFFFFFFFFFF00108F0100050745FFFFFFFFFFFFFFFF0084018204FFD74842FFFFFFFFFFFFFFFF011CA705FF93A646FFFFFFFFFFFFFFFF0117A70A000B9EC5FFFFFFFFFFFFFFFF0017AB0A000B9EC5FFFFFFFFFFFFFFFF0017AC0A000B9EC5FFFFFFFFFFFFFFFF0017A90A000B9EC5FFFFFFFFFFFFFFFF0017AA0A000B9EC5FFFFFFFFFFFFFFFF0017A80A000B9EC5FFFFFFFFFFFFFFFF0016B507989C0100BE9C011E829D')
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeHexa('839D')
        self.writeVInt(0)
        self.writeHexa('98548C9D')
        self.writeVInt(0)
        self.writeHexa('88')
        self.writeVInt(3)
        self.writeHexa('B5')
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeHexa('80')
        self.writeVInt(0)
        self.writeVInt(4)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeHexa('81')

        self.writeVInt(1)

        self.writeDataReference(41000091, 1) # themeID

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeHexa('9F')

        self.writeVInt(0)

        self.writeHexa('A3BB092F')
        self.writeVInt(0)
        self.writeHexa('BB')
        self.writeVInt(0)
        self.writeHexa('8803BC01A3BB09300332B4078C11B4078D1101AA0FB4078E110124010E010085CB080001010000000B56414C5545205041434B2100858772850108C6B35E000000')
        self.writeHexa('136F666665725F6267725F6C6F76657377616D70')
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(6)
        self.writeHexa('414E47454C4F')
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeInt(0)
        self.writeVInt(0)
        self.writeHexa('1D880C0002010202017F02010406001D8F01A9029D')
        self.writeHexa('05BB0A0600A0028207B407A21384270000001303AE1F6D')
        self.writeVInt(1)
        self.writeHexa('93')

        self.writeVInt(1)

        self.writeInt(0)
        self.writeInt(0)

        self.writeVInt(0)
        self.writeInt(0)
        self.writeVInt(1)
        self.writeInt(0)
        self.writeVInt(1)
        self.writeInt(0)
        self.writeVInt(0) # ?
        self.writeString('LRBS') # Angelo Value Pack!
        self.writeInt(0)
        self.writeHexa('2837366539383162343762663630373361393063373237366434656233356432316664356537366233') # (/76e981b47bf6073a90c7276d4eb35d21fd5e76b3)
        self.writeHexa('0000004B2F65656533646133312D613130302D343838372D383231362D6164333432653663663335655F303232385F416E67656C6F5F6561726C795F6163636573735F31303331783636332E706E67')
        self.writeString('brawlstars://shop') # brawlstars://shop
        self.writeVInt(0)

        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        
        self.writeVInt(1) # StarRoad

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        
        self.writeVInt(1)
        self.writeDataReference(16, 2)
        self.writeHexa('A002')
        self.writeVInt(1488)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        
        self.writeHexa('9303')
        self.writeDataReference(16, 5)
        self.writeHexa('A0021D000002001007AE068F0100000300100DA0021D000004001022AE068F01000005001003A0021D0000060110061006A0021D000006011003100E9D0EA90200000701101E101E9D0EA90200000701100E1001A0021D00000801000001A0021D00081009AE068F0100000901101B101BAE068F01000009011009101D9D0EA90200000A010000039D0EA902000A1002A0021D00000B01000001A0021D000B1016AE068F0100000C021019001019AE068F0100000C021016000002AE068F01000C10149D0EA90200000D02102D00102D9D0EA90200000D0210140000039D0EA902000D100BAC1D9D0500000E02101110151011AC1D9D0500000E02100B10151015AC1D9D0500000E02100B10111018A0021D00000F01000001A0021D000F1012AE068F0100001001000002AE068F0100100002AE068F01001010109D0EA902000011010000039D0EA902001100039D0EA90200111020AC1D9D0500001201000004AC1D9D0500120004AC1D9D0500121017983BBB0A00001302100C1005100C983BBB0A00001302101710051005983BBB0A000013021017100C0001A0021D00141013AE068F0100001501000002AE068F0100150002AE068F01001510329D0EA902000016010000039D0EA902001600039D0EA9020016102AAC1D9D0500001701000004AC1D9D0500170004AC1D9D0500171004AE068F0100001801000002AE068F0100180002AE068F010018102B9D0EA902000019010000039D0EA902001900039D0EA9020019101C983BBB0A00001A01000005983BBB0A001A0005983BBB0A001A100F9D0EA90200001B02101A00101A9D0EA90200001B02100F0000039D0EA902001B00039D0EA902001B103DAE068F0100001C01000002AE068F01001C0002AE068F01001C101FAC1D9D0500001D02102F00102FAC1D9D0500001D02101F000004AC1D9D05001D0004AC1D9D05001D10309D0EA90200001E010000039D0EA902001E00039D0EA902001E00039D0EA902001E1028983BBB0A00001F021034001034983BBB0A00001F021028000005983BBB0A001F0005983BBB0A001F0002AE068F0100200002AE068F01002010249D0EA902000021010000039D0EA902002100039D0EA902002100039D0EA9020021103F983BBB0A00002201000005983BBB0A00220005983BBB0A00220005983BBB0A00220002AE068F010023103A9D0EA902000024010000039D0EA902002400039D0EA902002400039D0EA90200241025AC1D9D0500002501000004AC1D9D0500250004AC1D9D0500250004AC1D9D0500251085019D0EA902000026010000039D0EA902002600039D0EA902002600039D0EA9020026108001AC1D9D0500002701000004AC1D9D0500270004AC1D9D0500270004AC1D9D0500271026983BBB0A00002801000005983BBB0A00280005983BBB0A00280005983BBB0A002810239D0EA902000029010000039D0EA902002900039D0EA902002900039D0EA9020029108301AC1D9D0500002A01000004AC1D9D05002A0004AC1D9D05002A0004AC1D9D05002A108601983BBB0A00002B01000005983BBB0A002B0005983BBB0A002B0005983BBB0A002B10279D0EA90200002C010000039D0EA902002C00039D0EA902002C00039D0EA902002C108701AC1D9D0500002D01000004AC1D9D05002D0004AC1D9D05002D0004AC1D9D05002D108C01983BBB0A00002E01000005983BBB0A002E0005983BBB0A002E0005983BBB0A002E108901AC1D9D0500002F01000004AC1D9D05002F0004AC1D9D05002F0004AC1D9D05002F0005983BBB0A00300005983BBB0A00300005983BBB0A003000039D0EA902003100039D0EA902003100039D0EA90200310004AC1D9D0500320004AC1D9D0500320004AC1D9D0500320005983BBB0A00330005983BBB0A0033102E9D0EA902000034010000039D0EA902003400039D0EA90200341029AC1D9D0500003501000004AC1D9D0500350004AC1D9D0500350005983BBB0A003610339D0EA902000037010000039D0EA902003700039D0EA9020037102CAC1D9D0500003801000004AC1D9D0500380004AC1D9D05003810359D0EA902000039010000039D0EA902003900039D0EA90200391031AC1D9D0500003A01000004AC1D9D05003A0004AC1D9D05003A103C9D0EA90200003B010000039D0EA902003B00039D0EA902003B1036AC1D9D0500003C01000004AC1D9D05003C0004AC1D9D05003C1081019D0EA90200003D010000039D0EA902003D00039D0EA902003D1038AC1D9D0500003E01000004AC1D9D05003E0004AC1D9D05003E1084019D0EA90200003F010000039D0EA902003F00039D0EA902003F')
        self.writeDataReference(16, 0)
        self.writeHexa('AC1D9D050000800101000004AC1D9D050080010004AC1D9D050080011088019D0EA90200008101010000039D0EA90200810100039D0EA902008101103BAC1D9D050000820101000004AC1D9D050082010004AC1D9D05008201108D019D0EA90200008301010000039D0EA90200830100039D0EA902008301103EAC1D9D050000840101000004AC1D9D050084010004AC1D9D0500840100039D0EA90200850100039D0EA902008501108201AC1D9D050000860101000004AC1D9D050086010004AC1D9D0500860100039D0EA902008701108B01AC1D9D050000880101000004AC1D9D050088010004AC1D9D05008801108A01AC1D9D050000890101000004AC1D9D050089010004AC1D9D050089010004AC1D9D05008A010004AC1D9D05008A010004AC1D9D05008B0103038B0104320532')
        self.writeInt(0)
        self.writeInt(0)
        self.writeInt(0)
        self.writeHexa('AA')
        self.writeVInt(0)
        self.writeHexa('5782')
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeHexa('9383')

        self.writeVInt(0)

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)

        self.writeInt(0)

        # LogicClientAvatar
        self.writeVLong(player.ID[0], player.ID[1]) # Id
        self.writeVLong(player.ID[0], player.ID[1]) # Id
        self.writeVLong(player.ID[0], player.ID[1]) # Id

        self.writeStringReference(player.Name) # name
        self.writeVInt(player.Registered) # name set
        self.writeInt(-1)

        self.writeVInt(17)
        unlocked_brawler = [i['CardID'] for x,i in player.OwnedBrawlers.items()]
        self.writeVInt(len(unlocked_brawler) + 2)
        for x in unlocked_brawler:
            self.writeDataReference(23, x)
            self.writeVInt(-1)
            self.writeVInt(1)

        self.writeDataReference(5, 8) # gold
        self.writeVInt(-64)
        self.writeVInt(player.Coins) # count

        self.writeVInt(1) # score array
        self.writeDataReference(16, 0) 
        self.writeVInt(-64)
        self.writeVInt(0) # count

        self.writeVInt(1) # high score array
        self.writeDataReference(16, 0) 
        self.writeVInt(-64)
        self.writeVInt(0) # count

        self.writeVInt(0)
        self.writeVInt(0) # power array

        self.writeVInt(1) # level array
        self.writeDataReference(16, 0) 
        self.writeVInt(-64)
        self.writeVInt(10) # count

        self.writeVInt(0) # star power, gadget, hypercharge array

        self.writeVInt(1) # seen state array
        self.writeDataReference(16, 0) 
        self.writeVInt(-64)
        self.writeVInt(2) # count

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)

        self.writeVInt(player.Gems) # gems
        self.writeVInt(0) # free gems
        self.writeVInt(1) # level
        self.writeVInt(100) # exp
        self.writeVInt(0) # CumulativePurchasedDiamonds or Avatar User Level Tier
        self.writeVInt(0) # Battle Count
        self.writeVInt(0) # WinCount
        self.writeVInt(0) # LoseCount
        self.writeVInt(0) # WinLooseStreak
        self.writeVInt(0) # NpcWinCount
        self.writeVInt(0) # NpcLoseCount
        self.writeVInt(2) # state
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString()
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)

    def decode(self):
        fields = {}
        # fields["AccountID"] = self.readLong()
        # fields["HomeID"] = self.readLong()
        # fields["PassToken"] = self.readString()
        # fields["FacebookID"] = self.readString()
        # fields["GamecenterID"] = self.readString()
        # fields["ServerMajorVersion"] = self.readInt()
        # fields["ContentVersion"] = self.readInt()
        # fields["ServerBuild"] = self.readInt()
        # fields["ServerEnvironment"] = self.readString()
        # fields["SessionCount"] = self.readInt()
        # fields["PlayTimeSeconds"] = self.readInt()
        # fields["DaysSinceStartedPlaying"] = self.readInt()
        # fields["FacebookAppID"] = self.readString()
        # fields["ServerTime"] = self.readString()
        # fields["AccountCreatedDate"] = self.readString()
        # fields["StartupCooldownSeconds"] = self.readInt()
        # fields["GoogleServiceID"] = self.readString()
        # fields["LoginCountry"] = self.readString()
        # fields["KunlunID"] = self.readString()
        # fields["Tier"] = self.readInt()
        # fields["TencentID"] = self.readString()
        #
        # ContentUrlCount = self.readInt()
        # fields["GameAssetsUrls"] = []
        # for i in range(ContentUrlCount):
        #     fields["GameAssetsUrls"].append(self.readString())
        #
        # EventUrlCount = self.readInt()
        # fields["EventAssetsUrls"] = []
        # for i in range(EventUrlCount):
        #     fields["EventAssetsUrls"].append(self.readString())
        #
        # fields["SecondsUntilAccountDeletion"] = self.readVInt()
        # fields["SupercellIDToken"] = self.readCompressedString()
        # fields["IsSupercellIDLogoutAllDevicesAllowed"] = self.readBoolean()
        # fields["isSupercellIDEligible"] = self.readBoolean()
        # fields["LineID"] = self.readString()
        # fields["SessionID"] = self.readString()
        # fields["KakaoID"] = self.readString()
        # fields["UpdateURL"] = self.readString()
        # fields["YoozooPayNotifyUrl"] = self.readString()
        # fields["UnbotifyEnabled"] = self.readBoolean()
        # super().decode(fields)
        return fields

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24101

    def getMessageVersion(self):
        return self.messageVersion
