from Classes.ClientsManager import ClientsManager
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import DatabaseHandler



class AllianceLeagueRanksTableMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0
        
    def encode(self, fields, player):
        self.writeHexa("0a-13-01-08-a8-01-a2-01-9d-01-8b-01-86-01-80-01-3b-36-09-01-04-04-04-00-00-00-00-00-02-08-8d-02-87-02-81-02-ab-01-a6-01-a1-01-9b-01-96-01-09-01-04-04-04-00-00-00-00-00-03-08-b3-02-ac-02-a6-02-8c-02-86-02-81-02-bb-01-b6-01-09-01-04-04-04-00-00-00-00-00-04-08-aa-03-a1-03-98-03-b4-02-ac-02-a4--02-9c-02-94-02-09-01-04-04-04-00-00-7f-7f-00-05-08-a1-04-98-04-8f-04-a4-03-9c-03-94-03-8c-03-84-03-09-01-04-04-00-00-00-7f-7f-00-06-08-9a-05-8f-05-86-05-94-04-8c-04-84-04-bc-03-b4-03-09-01-04-04-00-00-00-7f-7f-00-07-08-a3-06-97-06-8a-06-8d-05-82-05-b7-04-ad-04-a2-04-09-01-04-04-00-00-00-7f-7f-00-08-08-ad-07-a1-07-95-07-8d-06-82-06-b8-05-ad-05-a2-05-09-01-04-04-00-00-00-7f-7f-00-09-08-b8-08-ab-08-9e-08-8e-07-83-07-b8-06-ad-06-a3-06-09-01-04-04-00-00-00-7f-7f-00-0a-08-94-0a-85-0a-b5-09-96-08-89-08-bb-07-ae-07-a0-07-09-01-04-04-00-00-7f-7f-7f-00-0b-08-b8-0a-a8-0a-97-0a-b4-08-a6-08-97-08-89-08-bb-07-09-01-04-04-00-00-7f-7f-7f-00-0c-08-9d-0b-8c-0b-bb-0a-91-09-83-09-b3-08-a5-08-95-08-09-01-04-04-00-00-7f-7f-7f-00-0d-08-82-0c-b0-0b-9d-0b-af-09-a0-09-8f-09-80-09-b0-08-09-01-04-00-00-7f-7f-7f-7f-00-0e-08-a7-0c-94-0c-81-0c-8d-0a-bd-09-ac-09-9c-09-8b-09-09-01-04-00-00-7f-7f-7f-7f-00-0f-08-8a-0d-b8-0c-a3-0c-aa-0a-9a-0a-88-0a-b7-09-a5-09-09-01-04-00-00-7f-7f--7f-7f-00-10-08-af-0d-9c-0d-86-0d-88-0b-b7-0a-a4--0a-93-0a-80-0a-09-01-04-00-00-7f-7f-7f-7f-00-11-08-94-0e-bf-0d-a9-0d-a6-0b-94-0b-80-0b-ae-0a-9b-0a-09-01-04-00-00-7f-7f-7f-7f-00-12-08-b9-0e-a3--0e-8c-0e-83-0c-b1-0b-9c-0b-8a-0b-b5-0a-09-01-04--00-00-7f-7f-7f-7f-00-13-08-9e-0f-88-0f-b0-0e-a1--0c-8e-0c-b9-0b-a5-0b-90-0b-09-00-00-00-7f-7f-7f-7f-7f-00")


    def decode(self):
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 22173

    def getMessageVersion(self):
        return self.messageVersion