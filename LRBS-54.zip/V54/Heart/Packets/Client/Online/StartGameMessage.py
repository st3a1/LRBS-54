from Heart.Messaging import Messaging

from Heart.Packets.PiranhaMessage import PiranhaMessage
import time

class StartGameMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        fields = {}
        return fields

    def execute(message, calling_instance, fields, cryptoInit):
        bt = 10
        fields["Socket"] = calling_instance.client
        Messaging.sendMessage(20405, fields, cryptoInit)
        Messaging.sendMessage(24112, fields, cryptoInit)
        Messaging.sendMessage(20559, fields, cryptoInit)
        Messaging.sendMessage(24112, fields, cryptoInit)
        Messaging.sendMessage(24112, fields, cryptoInit)
        Messaging.sendMessage(24112, fields, cryptoInit)
        for x in range(200):
            bt += 1
            fields["battleTick"] = bt
            Messaging.sendMessage(24109, fields, cryptoInit)
            time.sleep(0.045)
        Messaging.sendMessage(24104, fields, cryptoInit)
        

    def getMessageType(self):
        return 14103

    def getMessageVersion(self):
        return self.messageVersion
     
     
     
 
        
     
		