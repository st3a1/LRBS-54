from Heart.Utils.ClientsManager import ClientsManager
from Heart.Packets.PiranhaMessage import PiranhaMessage
from Heart.Messaging import Messaging

from Heart.Record.ByteStream import ByteStream


class ClientCapabilitiesMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0
        

    def decode(self):
        fields = {}
        fields["Latency"] = self.readVInt()
        return fields

    def encode(self):
        pass
    
    def execute(message, calling_instance, fields, cryptoInit):
        pass

    def getMessageType(self):
        return 10107

    def getMessageVersion(self):
        return self.messageVersion