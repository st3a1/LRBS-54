from Heart.Utils.ClientsManager import ClientsManager
from Heart.Packets.PiranhaMessage import PiranhaMessage
from Heart.Messaging import Messaging

from Heart.Record.ByteStream import ByteStream


class AnalyticEventMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0
        

    def decode(self):
        fields = {}
        fields["Type"] = self.readString()
        fields["Event"] = self.readString()
        print(fields)
        return fields

    def encode(self):
        pass
    
    def execute(message, calling_instance, fields):
        print(fields["Event"])
        #if fields["Type"] == "Economy" and fields["Event"]['subType'] == "openShop":
#        	fields["Socket"] = calling_instance.client
#        	fields["PlayerID"] = calling_instance.player.ID
#        	fields["Command"] = {"ID": 211}
#        	Messaging.sendMessage(24111, fields)

    def getMessageType(self):
        return 10110

    def getMessageVersion(self):
        return self.messageVersion