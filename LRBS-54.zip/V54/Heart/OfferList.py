class offerlist
  pass