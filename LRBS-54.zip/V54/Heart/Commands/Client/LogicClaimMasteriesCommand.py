from Heart.Commands.LogicCommand import LogicCommand
from Heart.Messaging import Messaging
from DB.DatabaseHandler import DatabaseHandler
import json

class ClaimMasteriesCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        return self.messagePayload

    def decode(self, calling_instance):
        fields = {}
        fields["tick1"] = calling_instance.readVInt()
        calling_instance.readVInt()
        calling_instance.readVInt()
        calling_instance.readVInt()
        fields["brawler"] = calling_instance.readDataReference()
        fields["reward"] = calling_instance.readVInt()
        print(fields["brawler"])
        print(fields["reward"])
        return fields

    def execute(self, calling_instance, fields, cryptoInit):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        if fields["brawler"][1] == 35 or fields["brawler"][1] == 38 or fields["brawler"][1] == 39 or fields["brawler"][1] == 41 or fields["brawler"][1] == 44 or fields["brawler"][1] == 46 or fields["brawler"][1] == 49 or fields["brawler"][1] == 51 or fields["brawler"][1] == 53 or fields["brawler"][1] == 54 or fields["brawler"][1] == 56 or fields["brawler"][1] == 57 or fields["brawler"][1] == 59 or fields["brawler"][1] == 60 or fields["brawler"][1] == 62 or fields["brawler"][1] == 65 or fields["brawler"][1] == 66:
            if fields["reward"] == 2:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 1000, 'DataRef': [0, 0],  'RewardID': 7}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
            
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
            if fields["reward"] == 3:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 150, 'DataRef': [16, 0],  'RewardID': 24}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
            
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
            if fields["reward"] == 4:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 100, 'DataRef': [16, 0],  'RewardID': 22}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
            
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
            if fields["reward"] == 5:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 300, 'DataRef': [16, 0],  'RewardID': 24}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
            
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
            if fields["reward"] == 6:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 2000, 'DataRef': [16, 0],  'RewardID': 7}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
            
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
            if fields["reward"] == 7:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 100, 'DataRef': [16, 0],  'RewardID': 23}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
            
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
            if fields["reward"] == 8:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 50, 'DataRef': [16, 0],  'RewardID': 7}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
            
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
            if fields["reward"] == 9:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 50, 'DataRef': [16, 0],  'RewardID': 7}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
            
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
            if fields["reward"] == 10:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 50, 'DataRef': [16, 0],  'RewardID': 7}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
            
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)

    def getCommandType(self):
        return 569