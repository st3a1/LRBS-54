from Heart.Commands.LogicCommand import LogicCommand
from Heart.Messaging import Messaging
from DB.DatabaseHandler import DatabaseHandler
import json

class LogicBuyBrawlerCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        return self.messagePayload

    def decode(self, calling_instance):
        fields = {}
        fields["Tick1"] = calling_instance.readVInt()
        calling_instance.readVInt()
        calling_instance.readVInt()
        fields["VInst1"] = calling_instance.readVInt()
        fields["BrawlerID"] = calling_instance.readDataReference()
        calling_instance.readVInt()
        fields["Unk"] = calling_instance.readVInt()
        print(fields["Unk"])
        print(fields["VInst1"])
        return fields

    def execute(self, calling_instance, fields, cryptoInit):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        
        if fields["Unk"] == 20:
            if fields["BrawlerID"][1] == 66:
                player_data["ChromaCredits"] = player_data["ChromaCredits"] - 4500
            if fields["BrawlerID"][1] == 65:
                 player_data["ChromaCredits"] = player_data["ChromaCredits"] - 1500
            else:
                player_data["ChromaCredits"] = player_data["ChromaCredits"] - 500
        if fields["Unk"] != 20:
            if fields["BrawlerID"][1] == 66:
                player_data["Gems"] = player_data["Gems"] - 699
            if fields["BrawlerID"][1] == 65:
                player_data["Gems"] = player_data["Gems"] - 349
            else:
                player_data["Gems"] = player_data["Gems"] - 169
                
        #unlocked_BrawlerID = [0, 4, 8, 12, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60, 64, 68, 72, 95, 100, 105, 110, 115, 120, 125, 130, 177, 182, 188, 194, 200, 206, 218, 224, 230, 236, 279, 296, 303, 320, 327, 334, 341, 358, 365, 372, 379, 386, 393, 410, 417, 427, 434, 448, 466, 474, 491, 499, 507, 515, 523, 531, 539, 547, 557]
        if fields["BrawlerID"][1] == 35:
            player_data["Unlock"].append(224)
        if fields["BrawlerID"][1] == 38:
            player_data["Unlock"].append(279)
        if fields["BrawlerID"][1] == 39:
            player_data["Unlock"].append(296)
        if fields["BrawlerID"][1] == 41:
            player_data["Unlock"].append(320)
        if fields["BrawlerID"][1] == 44:
            player_data["Unlock"].append(341)
        if fields["BrawlerID"][1] == 46:
            player_data["Unlock"].append(365)
        if fields["BrawlerID"][1] == 49:
            player_data["Unlock"].append(386)
        if fields["BrawlerID"][1] == 51:
            player_data["Unlock"].append(410)
        if fields["BrawlerID"][1] == 53:
            player_data["Unlock"].append(427)
        if fields["BrawlerID"][1] == 54:
            player_data["Unlock"].append(434)
        if fields["BrawlerID"][1] == 56:
            player_data["Unlock"].append(448)
        if fields["BrawlerID"][1] == 57:
            player_data["Unlock"].append(466)
        if fields["BrawlerID"][1] == 59:
            player_data["Unlock"].append(491)
        if fields["BrawlerID"][1] == 60:
            player_data["Unlock"].append(499)
        if fields["BrawlerID"][1] == 62:
            player_data["Unlock"].append(515)
        if fields["BrawlerID"][1] == 65:
            player_data["Unlock"].append(539)
        if fields["BrawlerID"][1] == 66:
            player_data["Unlock"].append(547)
            
                
        player_data["delivery_items"] = {
            'Boxes': []
        }
        box = {
       'Type': 0,
       'Items': []
        }
        item = {'Amount': 1, 'DataRef': [16, fields["BrawlerID"][1]],  'RewardID': 1}
        box['Type'] = 100
        box['Items'].append(item)
        player_data["delivery_items"]['Boxes'].append(box)
            
        db_instance.updatePlayerData(player_data, calling_instance)
        fields["Socket"] = calling_instance.client
        fields["Command"] = {"ID": 203}
        fields["PlayerID"] = calling_instance.player.ID
        Messaging.sendMessage(24111, fields, cryptoInit)

    def getCommandType(self):
        return 560