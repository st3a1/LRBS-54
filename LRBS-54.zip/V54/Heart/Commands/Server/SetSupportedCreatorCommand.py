from Heart.Commands.LogicServerCommand import LogicServerCommand

from DB.DatabaseHandler import DatabaseHandler
import json


class SetSupportedCreatorCommand(LogicServerCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        self.writeVInt(1)
        self.writeString("")
        self.writeVInt(1)
        LogicServerCommand.encode(self, fields)
        return self.messagePayload

    def getCommandType(self):
        return 215