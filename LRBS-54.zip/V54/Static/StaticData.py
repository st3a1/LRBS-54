import json

class StaticData:
    offers = None
    EventsData = None
    QuestsData = None

    def Preload():
        StaticData.offers = json.loads(open("Heart/Static/offers.json", 'r').read())
        StaticData.EventsData = json.loads(open("Heart/Static/Events.json", 'r').read())
        StaticData.QuestsData = json.loads(open("Heart/Utils/Quests.json", 'r').read())